                      :::!~!!!!!:.
                  .xUHWH!! !!?M88WHX:.
                .X*#M@$!!  !X!M$$$$$$WWx:.
               :!!!!!!?H! :!$!$$$$$$$$$$8X:
              !!~  ~:~!! :~!$!#$$$$$$$$$$8X:
             :!~::!H!<   ~.U$X!?R$$$$$$$$MM!
             ~!~!!!!~~ .:XW$$$U!!?$$$$$$RMM!
               !:~~~ .:!M"T#$$$$WX??#MRRMMM!
               ~?WuxiW*`   `"#$$$$8!!!!??!!!
             :X- M$$$$       `"T#$T~!8$WUXU~
            :%`  ~#$$$m:        ~!~ ?$$$$$$
          :!`.-   ~T$$$$8xx.  .xWW- ~""##*"
.....   -~~:<` !    ~?T#$$@@W@*?$$      /`
W$@@M!!! .!~~ !!     .:XUW$W!~ `"~:    :
#"~~`.:x%`!!  !H:   !WM$$$$Ti.: .!WUn+!`
:::~:!!`:X~ .: ?H.!u "$$$B$$$!W:U!T$$M~
.~~   :X@!.-~   ?@WTWo("*$$$W$TH$! `
Wi.~!X$?!-~    : ?$$$B$Wu("**$RM!
$R@i.~~ !     :   ~$$$$$B$$en:``
?MXT@Wx.~    :     ~"##*$$$$M~


___________________ ____   ____ _____ __________ 
\_   _____/\_____  \\   \ /   //  |  |\______   \
 |    __)    _(__  < \   Y   //   |  |_|       _/
 |     \    /       \ \     //    ^   /|    |   \
 \___  /   /______  /  \___/ \____   | |____|_  /
     \/           \/              |__|        \/ 

                       .__.__      _____              __                 
   ____   _____ _____  |__|  |   _/ ____\_ __   ____ |  | __ ___________ 
  / ___\ /     \\__  \ |  |  |   \   __\  |  \_/ ___\|  |/ // __ \_  __ \
 / /_/  >  Y Y  \/ __ \|  |  |__  |  | |  |  /\  \___|    <\  ___/|  | \/
 \___  /|__|_|  (____  /__|____/  |__| |____/  \___  >__|_ \\___  >__|   
/_____/       \/     \/                            \/     \/    \/        

You can scan this in virustotal, however virustotal is being retarded so it gives 10 false positives, try ignoring them
---------------------
If you dont trust this you can just run it in a virtual machine, or in windows sandbox ( or just delete it )
---------------------
By the way in order to log into the gmail you'll use for spamming you need 2 step verification on your gmail, and generate an app password that you must use as the acc pass when it prompts u with the login, tutorial down below:

https://www.youtube.com/watch?v=J4CtP1MBtOE
---------------------
VIRUSTOTAL LINK: https://www.virustotal.com/gui/file/8e7f4fc6ca9631a45600d47fd679eb5085105a80883c658a1567a8a72eaa920a/summary
---------------------
Discord Tag: F3V4R#6608
---------------------
DONT FALL FOR FAKE GITHUB POSTS!